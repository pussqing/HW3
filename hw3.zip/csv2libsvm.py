##
# create by zhenyuxiaoge on 2016/11/25
##

# transform data.txt to libsvm type data, get libsvm.txt

#read data file
readin = open('breast-cancer_scale.txt', 'r')
#write data file
output = open('breast-cancer_scale_svm.txt', 'w')
try:
    the_line = readin.readline()
    while the_line:
        # delete the \n
        the_line = the_line.strip('\n')
        index = 0;
        output_line = ''
        for sub_line in the_line.split('\t'):
            #the label col
            if index == 0:
                output_line = sub_line
            #the features cols
            if sub_line != 'NULL' and index != 0:
                the_text = ' ' + str(index) + ':' + sub_line
                output_line = output_line + the_text
            index = index + 1
        output_line = output_line + '\n'
        output.write(output_line)
        the_line = readin.readline()
finally:
    readin.close()
