readin=open("breast-cancer_scale.txt",'r')
output=open("breast-cancer.txt",'w')

try:
    the_line=readin.readline()
    while the_line:

        the_line = the_line.strip('\n')
        index = 0;
        output_line = ''

        for sub_line in the_line.split(' '):
            if index==0:
                output_line+=sub_line
                index+=1
                #print index,"hello\n"
            if index!=0 and sub_line!='NULL':
                for i in range(len(sub_line)):
                    if sub_line[i]==':':
                        #print index,sub_line[i+1:],'\n'
                        output_line+=','+sub_line[i+1:]
                        break
                index+=1

        output_line+='\n'
        output.write(output_line)
        the_line=readin.readline()


finally:
    readin.close()
