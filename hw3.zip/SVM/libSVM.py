import os
os.chdir("E:\SunnyQing\libsvm-3.22\python")

from svmutil import *
from sklearn.model_selection import train_test_split


x, y = svm_read_problem('E:\\SunnyQing\\libsvm-3.22\\python\\breast-cancer_scale_svm.txt')

X_train, X_test, Y_train, Y_test = train_test_split(
    x, y, test_size=0.30, random_state=42)

prob = svm_problem(X_train,Y_train)

param = svm_parameter()
param.kernel_type = RBF
param.C = 9
param.gamma = 0.000000001



m = svm_train(prob, param)



print "kernel:",param.kernel_type
print "C:",param.C

svm_save_model('iot_a4.model',m)


#a, b = svm_read_problem("E:\\SunnyQing\\libsvm-3.22\\python\\breast-cancer_scale_svm.txt")

m = svm_load_model('iot_a4.model')

p_labs, p_acc, p_vals = svm_predict(X_test,Y_test,m)

print p_acc
